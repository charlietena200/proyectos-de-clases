﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Windows.Forms;

namespace Proyecto
{
    class Program
    {
        static void Main(string[] args)
        {
            Application.Run(new Interfaz());
        }
    }
}
